﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project7_KS_DrivingDistances
{
    public partial class DrivingDistances : Form
    {
        public DrivingDistances()
        {
            InitializeComponent();
        }

        double[,] drivingDistancesArray = {{0, 1004, 1753, 2752, 3017, 1520, 1507, 609, 3155, 448}, 
                                       {1004, 0, 921, 1780, 2048, 1397, 919, 515, 2176, 709}, 
                                       {1753, 921, 0, 1230, 1399, 1343, 517, 1435, 2234, 1307}, 
                                       {2752, 1780, 1230, 0, 272, 2570, 1732, 2251, 1322, 2420}, 
                                       {3017, 2048, 1399, 272, 0, 2716, 1858, 2523, 1278, 2646}, 
                                       {1520, 1397, 1343, 2570, 2716, 0, 860, 1494, 3447, 1057}, 
                                       {1507, 919, 517, 1732, 1858, 860, 0, 1307, 2734, 1099}, 
                                       {609, 515, 1435, 2251, 2523, 1494, 1307, 0, 2820, 571}, 
                                       {3155, 2176, 2234, 1322, 1278, 3447, 2734, 2820, 0, 2887}, 
                                       {448, 709, 1307, 2420, 2646, 1057, 1099, 571, 2887, 0}};

        private void DrivingDistances_Load(object sender, EventArgs e)
        {
            departureErrorLabel.Hide();
            destinationErrorLabel.Hide();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            departureComboBox.SelectedIndex = -1;
            destinationComboBox.SelectedIndex = -1;
            departureErrorLabel.Hide();
            destinationErrorLabel.Hide();
            distanceLabel.Text = "";
            kiloDistanceLabel.Text = "";
            hoursLabel.Text = "";
            minutesLabel.Text = "";

        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            ////prep
            //int departure, destination, size;
            //double distance;

            ////vali
            //if (departureComboBox.SelectedIndex <0)
            //{
            //    departureErrorLabel.Show();
            //    return;
            //}
            //if (destinationComboBox.SelectedIndex < 0)
            //{
            //    destinationErrorLabel.Show();
            //    return;
            //}

            ////pull value
            //distance = drivingDistancesArray[departure, destination];


            //prep
            int departure = departureComboBox.SelectedIndex;
            int destination = destinationComboBox.SelectedIndex;
            int hours, minutes;
            double distance, kilodistance;

            //vari
            if (departure < 0)
            {
                departureErrorLabel.Show();
                return;
            }
            if (destination < 0)
            {
                destinationErrorLabel.Show();
                return;
            }
            //distance calc
            distance = drivingDistancesArray[departure, destination];
            kilodistance = drivingDistancesArray[departure, destination] * 1.60934;
            distanceLabel.Text = distance.ToString();
            kiloDistanceLabel.Text = kilodistance.ToString();

            //time calc
            //minutes = (int)distance / 43;
            //minutesLabel.Text(ToString) = minutes;
            if (distance%43==0)
            {
                hours = (int)(distance / 43);
                hoursLabel.Text = hours.ToString();
            }
            else
            {
                hours = (int)(distance - (distance % 43)) / 43;
                minutes = (int)((distance % 43) / 43 * 60);
                hoursLabel.Text = hours.ToString();
                minutesLabel.Text = minutes.ToString();
            }
            
        }

        private void departureComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            //define index(posi) selected from combox
            int index = departureComboBox.SelectedIndex;
            //if index >= 0 the user has selected a city
            if (index >= 0)
            {
                //hide the error label
                departureErrorLabel.Hide();
                //display the beautiful pic
                departurePictureBox.Image = citiesImageList.Images[index];
            }
            else
            {
                //blank out the picturebox
                departurePictureBox.Image = null;
            }

        }

        private void destinationComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            //define index(posi) selected from combox
            int index = destinationComboBox.SelectedIndex;
            //if index >= 0 the user has selected a city
            if (index >= 0)
            {
                //hide the error label
                destinationErrorLabel.Hide();
                //display the beautiful pic
                destinationPictureBox.Image = citiesImageList.Images[index];
            }
            else
            {
                //blank out the picturebox
                destinationPictureBox.Image = null;
            }

    

        }
    }
}
