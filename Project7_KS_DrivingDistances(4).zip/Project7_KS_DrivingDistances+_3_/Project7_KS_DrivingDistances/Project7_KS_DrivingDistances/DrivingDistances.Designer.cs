﻿namespace Project7_KS_DrivingDistances
{
    partial class DrivingDistances
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DrivingDistances));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.departureComboBox = new System.Windows.Forms.ComboBox();
            this.departurePictureBox = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.distanceLabel = new System.Windows.Forms.Label();
            this.hoursLabel = new System.Windows.Forms.Label();
            this.minutesLabel = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.destinationComboBox = new System.Windows.Forms.ComboBox();
            this.kiloDistanceLabel = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.departureErrorLabel = new System.Windows.Forms.Label();
            this.destinationErrorLabel = new System.Windows.Forms.Label();
            this.citiesImageList = new System.Windows.Forms.ImageList(this.components);
            this.destinationPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.departurePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.destinationPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Kaleb Sandin";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "ITS 128";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(37, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(135, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Project 7 Driving Distances";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(148, 122);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Departure";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(323, 122);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Destination";
            // 
            // departureComboBox
            // 
            this.departureComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.departureComboBox.FormattingEnabled = true;
            this.departureComboBox.Items.AddRange(new object[] {
            "Boston",
            "Chicago",
            "Dallas",
            "Las Vegas",
            "Los Angeles",
            "Miami",
            "New Orleans",
            "Toronto",
            "Vancouver",
            "Washington DC"});
            this.departureComboBox.Location = new System.Drawing.Point(110, 148);
            this.departureComboBox.Name = "departureComboBox";
            this.departureComboBox.Size = new System.Drawing.Size(121, 21);
            this.departureComboBox.TabIndex = 0;
            this.departureComboBox.SelectedIndexChanged += new System.EventHandler(this.departureComboBox_SelectedIndexChanged);
            // 
            // departurePictureBox
            // 
            this.departurePictureBox.Location = new System.Drawing.Point(92, 206);
            this.departurePictureBox.Name = "departurePictureBox";
            this.departurePictureBox.Size = new System.Drawing.Size(139, 110);
            this.departurePictureBox.TabIndex = 6;
            this.departurePictureBox.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(37, 358);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Distance in Miles";
            // 
            // distanceLabel
            // 
            this.distanceLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.distanceLabel.Location = new System.Drawing.Point(140, 346);
            this.distanceLabel.Name = "distanceLabel";
            this.distanceLabel.Size = new System.Drawing.Size(111, 34);
            this.distanceLabel.TabIndex = 8;
            // 
            // hoursLabel
            // 
            this.hoursLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.hoursLabel.Location = new System.Drawing.Point(188, 413);
            this.hoursLabel.Name = "hoursLabel";
            this.hoursLabel.Size = new System.Drawing.Size(88, 29);
            this.hoursLabel.TabIndex = 9;
            // 
            // minutesLabel
            // 
            this.minutesLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.minutesLabel.Location = new System.Drawing.Point(349, 413);
            this.minutesLabel.Name = "minutesLabel";
            this.minutesLabel.Size = new System.Drawing.Size(96, 29);
            this.minutesLabel.TabIndex = 10;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(54, 429);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(118, 13);
            this.label10.TabIndex = 11;
            this.label10.Text = "Driving time @ 43 MPH";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(292, 429);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(24, 13);
            this.label11.TabIndex = 12;
            this.label11.Text = "hrs.";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(463, 429);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(26, 13);
            this.label12.TabIndex = 13;
            this.label12.Text = "min.";
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(76, 476);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 2;
            this.calculateButton.Text = "&Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(237, 476);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 3;
            this.clearButton.Text = "C&lear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(398, 476);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "E&xit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // destinationComboBox
            // 
            this.destinationComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.destinationComboBox.FormattingEnabled = true;
            this.destinationComboBox.Items.AddRange(new object[] {
            "Boston",
            "Chicago",
            "Dallas",
            "Las Vegas",
            "Los Angeles",
            "Miami",
            "New Orleans",
            "Toronto",
            "Vancouver",
            "Washington DC"});
            this.destinationComboBox.Location = new System.Drawing.Point(296, 148);
            this.destinationComboBox.Name = "destinationComboBox";
            this.destinationComboBox.Size = new System.Drawing.Size(121, 21);
            this.destinationComboBox.TabIndex = 1;
            this.destinationComboBox.SelectedIndexChanged += new System.EventHandler(this.destinationComboBox_SelectedIndexChanged);
            // 
            // kiloDistanceLabel
            // 
            this.kiloDistanceLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.kiloDistanceLabel.Location = new System.Drawing.Point(398, 346);
            this.kiloDistanceLabel.Name = "kiloDistanceLabel";
            this.kiloDistanceLabel.Size = new System.Drawing.Size(111, 34);
            this.kiloDistanceLabel.TabIndex = 18;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(277, 358);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(110, 13);
            this.label14.TabIndex = 19;
            this.label14.Text = "Distance in kilometers";
            // 
            // departureErrorLabel
            // 
            this.departureErrorLabel.AutoSize = true;
            this.departureErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.departureErrorLabel.Location = new System.Drawing.Point(107, 181);
            this.departureErrorLabel.Name = "departureErrorLabel";
            this.departureErrorLabel.Size = new System.Drawing.Size(134, 13);
            this.departureErrorLabel.TabIndex = 20;
            this.departureErrorLabel.Text = "Select a departure location";
            // 
            // destinationErrorLabel
            // 
            this.destinationErrorLabel.AutoSize = true;
            this.destinationErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.destinationErrorLabel.Location = new System.Drawing.Point(283, 181);
            this.destinationErrorLabel.Name = "destinationErrorLabel";
            this.destinationErrorLabel.Size = new System.Drawing.Size(140, 13);
            this.destinationErrorLabel.TabIndex = 21;
            this.destinationErrorLabel.Text = "Select a destination location";
            // 
            // citiesImageList
            // 
            this.citiesImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("citiesImageList.ImageStream")));
            this.citiesImageList.TransparentColor = System.Drawing.Color.Transparent;
            this.citiesImageList.Images.SetKeyName(0, "boston.jpg");
            this.citiesImageList.Images.SetKeyName(1, "chicago.jpg");
            this.citiesImageList.Images.SetKeyName(2, "dallas.jpg");
            this.citiesImageList.Images.SetKeyName(3, "lasvegas.jpg");
            this.citiesImageList.Images.SetKeyName(4, "losangeles.jpg");
            this.citiesImageList.Images.SetKeyName(5, "miami.jpg");
            this.citiesImageList.Images.SetKeyName(6, "neworleans.jpg");
            this.citiesImageList.Images.SetKeyName(7, "toronto.jpg");
            this.citiesImageList.Images.SetKeyName(8, "vancouver.jpg");
            this.citiesImageList.Images.SetKeyName(9, "washingtondc.jpeg");
            // 
            // destinationPictureBox
            // 
            this.destinationPictureBox.Location = new System.Drawing.Point(286, 206);
            this.destinationPictureBox.Name = "destinationPictureBox";
            this.destinationPictureBox.Size = new System.Drawing.Size(139, 110);
            this.destinationPictureBox.TabIndex = 22;
            this.destinationPictureBox.TabStop = false;
            // 
            // DrivingDistances
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(553, 516);
            this.Controls.Add(this.destinationPictureBox);
            this.Controls.Add(this.destinationErrorLabel);
            this.Controls.Add(this.departureErrorLabel);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.kiloDistanceLabel);
            this.Controls.Add(this.destinationComboBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.minutesLabel);
            this.Controls.Add(this.hoursLabel);
            this.Controls.Add(this.distanceLabel);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.departurePictureBox);
            this.Controls.Add(this.departureComboBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "DrivingDistances";
            this.Text = "Driving Distances";
            this.Load += new System.EventHandler(this.DrivingDistances_Load);
            ((System.ComponentModel.ISupportInitialize)(this.departurePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.destinationPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox departureComboBox;
        private System.Windows.Forms.PictureBox departurePictureBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label distanceLabel;
        private System.Windows.Forms.Label hoursLabel;
        private System.Windows.Forms.Label minutesLabel;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ComboBox destinationComboBox;
        private System.Windows.Forms.Label kiloDistanceLabel;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label departureErrorLabel;
        private System.Windows.Forms.Label destinationErrorLabel;
        private System.Windows.Forms.ImageList citiesImageList;
        private System.Windows.Forms.PictureBox destinationPictureBox;
    }
}

